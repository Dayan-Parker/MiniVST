autowatch = 1;

var push = null;
var matrix = null;
var buttons = null;
var displines = null;

var startfen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR"

var blinking = null;
var blinkstate = 0;

var colors = {
	'black' : 0,
	'white' : 2,
	
	'White Pawn' : 67,
	'White Knight' : 28,
	'White Bishop' : 30,
	'White Rook' : 29,
	'White Queen' : 87,
	'White King' : 17,	

	'Black Pawn' : 96,
	'Black Knight' : 61,
	'Black Bishop' : 59,
	'Black Rook' : 60,
	'Black Queen' : 72,
	'Black King' : 57,
};

var fenlu = {
	'P' : 'White Pawn',
	'N' : 'White Knight',
	'B' : 'White Bishop',
	'R' : 'White Rook',
	'Q' : 'White Queen',
	'K' : 'White King',

	'p' : 'Black Pawn',
	'n' : 'Black Knight',
	'b' : 'Black Bishop',
	'r' : 'Black Rook',
	'q' : 'Black Queen',
	'k' : 'Black King',
};

var tsk = new Task(blinker);


function eval(type, value)
{
	var message;
	var howawesome;

	if (type === "pawn") {
		message = "eval: " + value.toFixed(3);
		howawesome = value * 3.;
	} else if (type === "mate") {
		message = "mate in " + value;
		howawesome = 4;
	}
	displines[3].call("display_message", message);

	if (howawesome > 0) {
		howawesome = Math.floor(howawesome);
		if (howawesome > 4) howawesome = 4;
		var triggerclip = new LiveAPI("live_set scenes " + howawesome + " clip_slots 1");
		if (triggerclip) {
			triggerclip.call("fire");
		}
	} else {
		var track = new LiveAPI("live_set tracks 1");
		if (track) {
			track.call("stop_all_clips");
		}
	}

}

function blinker()
{
	blink_button();
}

function bang() 
{
	if (!verify_push()) return;

	var controls = push.call("get_control_names");
	var controlname = "";
	var controlcount = 0;
		//return;
	for (var i in controls) {
		if (controls[i] !== "control" && controls[i] !== "done") {
			if (controlname !== "") controlname += " ";
			controlname += controls[i];
		} else if (controlname !== "") {
			post(controlcount++ + " | " + controlname);
			post();
			controlname = ""
		}
	}	
}

function settitle()
{
	if (!verify_push()) return;
	
	displines[0].call("display_message", "Schach dem König, suckah!");
}

function display_frompiece(msg)
{
	if (!verify_push()) return;
	
	displines[1].call("display_message", msg);
}

function blink_button(x, y)
{
	var cellno;

	if (!verify_push()) return;
		
	if (!blinking) {
		cellno = y * 8 + x;

		//if (buttons[cellno] == 0) return;

		blinking = [x, y];
		blinkstate = 0;	
	
		for (var c in colors) {
			if (colors[c] == buttons[cellno]) {
				display_frompiece(c);
			}
		}
	}
	
	cellno = blinking[1] * 8 + blinking[0];
	if (!blinkstate) {
		matrix.call("send_value", blinking[0], blinking[1], buttons[cellno]);
		blinkstate = 1;
	} else {
		var colorval = (blinking[0]%2 == blinking[1]%2) ? colors.white : colors.black;

		matrix.call("send_value", blinking[0], blinking[1], colorval);
		blinkstate = 0;
	}
	tsk.schedule(250);	
}

function blink_button_stop()
{
	if (!verify_push()) return;
	
	tsk.cancel();
	if (blinking) {
		if (buttons[blinking[1] * 8 + blinking[0]] !== 0) {
			matrix.call("send_value", blinking[0], blinking[1], buttons[blinking[1] * 8 + blinking[0]]);
		}
		blinking = null;
		blinkstate = 0;
	}
}

function move(algebraic, coords, ply, success)
{
	display_frompiece((Math.floor(ply / 2) + 1) + (ply % 2 ? ". " : "...") + algebraic + (success ? "" : " is an     invalid move."));
	if (success) {
		blink_button_stop();

		var pattrand = new LiveAPI("live_set tracks 0 devices 0 parameters 19");
		pattrand.set("value", 1);
		pattrand.set("value", 0);
		var noterand = new LiveAPI("live_set tracks 0 devices 0 parameters 14");
		noterand.set("value", 1);
		noterand.set("value", 0);
	}
}

function cb(args)
{
	//post("this: " + Object.prototype.toString.call(this).match(/^\[object\s(.*)\]$/)[1] + "\n");
	if (args[0] === "value") {
		if (args[1] !== "bang" && args[1] != "0") { // this appears to be a Live bug, filtering for now
			if (!blinking) {
				blink_button(args[2], args[3]);
			} else if (blinking[0] == args[2] && blinking[1] == args[3]) {
				blink_button_stop();
			} else {
				//post(String.fromCharCode(blinking[0] + 97) + (8 - blinking[1]) + " - " + String.fromCharCode(args[2] + 97) + (8 - args[3]) + '\n');
				outlet(0, "move", String.fromCharCode(blinking[0] + 97) + (8 - blinking[1]) + String.fromCharCode(args[2] + 97) + (8 - args[3]))
			}
			//var vel = args[1];
			//var x = args[2];
			//var y = args[3];
			//var momentary = args[4];
            //
			//show_single(x,y,vel);
		}
		
	} //else post("cb args: " + args + "\n");
}

function show_single(x, y, vel)
{
	if (!verify_push()) return;

	matrix.call("send_value", x, y, vel);
}

function reset()
{
	fen();
}

function fen(fenstr)
{
	if (!verify_push()) return;

	if (!fenstr || fenstr === "") {
		fenstr = startfen;
	}
	if (matrix) {
		var colorval;
		//post(fenstr); post();
		var ct = 0;
		for (var f in fenstr) {
			if (fenstr[f] == " ") break;
			if (!isNaN(parseFloat(fenstr[f])) && isFinite(fenstr[f])) {
				var toskip = parseInt(fenstr[f]);
				while (toskip--) {
					buttons[ct++] = 0;
				}
			} else {
				var colorname = fenlu[fenstr[f]];
				
				if (colorname) {
					colorval = colors[colorname];
				} else {
					ct--;
					colorval = -1;
				}
				if (colorval >= 0) {
					buttons[ct] = colorval;
					matrix.call("send_value", Math.floor(ct%8), Math.floor(ct/8), colorval);
				}
				ct++;
			}
		}
		for (ct = 0; ct < 64; ct++) {
			var x = Math.floor(ct%8);
			var y = Math.floor(ct/8);
			colorval = (x%2 == y%2) ? colors.white : colors.black;
			if (buttons[ct] == 0) {
				matrix.call("send_value", x, y, colorval);
			}
		}
	}
	return;
}

function verify_push()
{
	if (!push) {
		push = new LiveAPI("control_surfaces 0");
	}
	if (!push) return false;
	
	if (!matrix) {
		matrixid = push.call("get_control", "Button_Matrix").join(" ");
		push.call("grab_control", matrixid);
		matrix = new LiveAPI(cb, matrixid);
		matrix.property = "value"; // observe the matrix value
	}
	if (!matrix) return false;

	if (!buttons) {
		buttons = new Array(64);
		for (var ct = 0; ct < 64; ct++) {
			buttons[ct] = 0;
		}
	}
	if (!buttons) return false;
	
	if (!displines) {
		displines = new Array(4);
		
		for (var i = 0; i < 4; i++) {
			var displayid = push.call("get_control", "Display_Line_" + i).join(" ");
			push.call("grab_control", displayid);
			displines[i] = new LiveAPI(displayid);
		}
	}
	if (!displines) return false;
	
	return true;
}

function grab()
{
	if (!verify_push()) return;
	post("grabbed\n");
}

function release()
{
	if (displines) {
		for (var i in displines) {
			push.call("release_control", "id " + displines[i].id);
			delete displines[i];
		}
		displines.length = 0;
		displines = null;
	}
	if (buttons) {
		buttons.length = 0;
		buttons = null;
	}
	if (matrix) {
		push.call("release_control", "id " + matrix.id);
		delete matrix;
		matrix = null;
	}
	if (push) {
		delete push;
		push = null;
	}
	post("released\n");
}

function show_lookup(lookup)
{
	for (var i = 0; i < 128; i++) {
		for (var ct = 0; ct < 64; ct++) {
			matrix.call("send_value", Math.floor(ct%8), Math.floor(ct/8), lookup[i]);
		}
	}
}

function show_hue(v)
{
	if (!verify_push()) return;

	if (v) {
		for (var ct = 0; ct < 64; ct++) {
			matrix.call("send_value", Math.floor(ct%8), Math.floor(ct/8), huelookup[v]);
		}
		post("hue: real vel = " + huelookup[v] + "\n");
	} else {
		show_lookup(huelookup);
	}
}

function show_sat(v)
{
	if (!verify_push()) return;

	if (v) {
		for (var ct = 0; ct < 64; ct++) {
			matrix.call("send_value", Math.floor(ct%8), Math.floor(ct/8), satlookup[v]);
		}
		post("sat: real vel = " + satlookup[v] + "\n");
	} else {
		show_lookup(satlookup);
	}
}	
	
function show_bri(v)
{
	if (!verify_push()) return;

	if (v) {
		for (var ct = 0; ct < 64; ct++) {
			matrix.call("send_value", Math.floor(ct%8), Math.floor(ct/8), brilookup[v]);
		}
		post("bri: real vel = " + brilookup[v] + "\n");
	} else {
		show_lookup(brilookup);
	}
}	


var huelookup = [ 0, 7, 1, 71, 121, 117, 6, 118, 70, 2, 120, 3, 4, 5, 72, 60, 107, 127, 84, 10, 9, 61, 108, 105, 96, 83, 126, 8, 62, 11, 99, 100, 125, 109, 124, 97, 15, 14, 12, 13, 113, 74, 73, 63, 110, 85, 98, 111, 19, 86, 75, 16, 17, 18, 122, 76, 123, 88, 101, 64, 23, 22, 20, 87, 21, 27, 25, 24, 89, 26, 30, 29, 28, 114, 77, 31, 34, 32, 33, 65, 102, 35, 90, 119, 68, 38, 36, 78, 37, 66, 39, 40, 41, 42, 43, 91, 92, 79, 104, 47, 103, 112, 46, 44, 45, 67, 115, 93, 69, 80, 50, 116, 51, 49, 48, 81, 94, 55, 54, 52, 53, 82, 59, 95, 56, 57, 58, 106,  ];
var satlookup = [ 0, 1, 71, 117, 118, 70, 2, 3, 119, 112, 115, 93, 114, 103, 8, 113, 116, 91, 89, 4, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 107, 105, 92, 104, 90, 101, 110, 73, 102, 109, 88, 82, 108, 94, 111, 86, 99, 75, 127, 85, 74, 7, 15, 23, 27, 35, 39, 43, 47, 55, 31, 59, 11, 19, 51, 121, 100, 64, 125, 83, 123, 68, 38, 65, 6, 10, 14, 18, 22, 26, 30, 34, 42, 46, 54, 58, 63, 50, 62, 66, 76, 61, 120, 106, 126, 124, 97, 69, 122, 72, 5, 60, 84, 9, 96, 13, 98, 17, 21, 87, 25, 29, 77, 33, 37, 78, 41, 79, 67, 45, 80, 49, 81, 53, 95, 57,  ];
var brilookup = [ 0, 7, 15, 23, 27, 35, 39, 43, 47, 55, 31, 59, 11, 19, 51, 121, 100, 64, 1, 125, 103, 71, 83, 123, 127, 112, 68, 38, 65, 6, 10, 14, 18, 22, 26, 30, 34, 42, 46, 54, 58, 101, 102, 63, 50, 104, 62, 66, 117, 105, 99, 76, 61, 120, 106, 126, 124, 97, 111, 82, 69, 122, 85, 118, 74, 108, 92, 70, 2, 5, 72, 60, 84, 9, 96, 13, 98, 17, 87, 21, 25, 29, 77, 33, 78, 37, 41, 79, 45, 67, 80, 49, 81, 53, 95, 57, 75, 110, 86, 107, 94, 109, 88, 73, 90, 4, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 89, 91, 116, 93, 113, 8, 114, 115, 119, 3,  ];
